/* Integration adapter. Upstream exploit files remain unchanged in vendor/. */
(function () {
 'use strict';
 var button=document.getElementById('start-loader'),status=document.getElementById('loader-status'),detail=document.getElementById('loader-detail');
 var cards=document.querySelectorAll('[data-version]');
 var compatible=/PlayStation 4[ \/]9\.00(?:[;\s\)]|$)/i.test(navigator.userAgent),busy=false;
 function say(a,b){status.textContent=a;detail.textContent=b;}
 function update(){button.disabled=busy||!compatible;for(var n=0;n<cards.length;n++){var r=find(cards[n].getAttribute('data-version'));cards[n].disabled=busy||!r||!r.available;}}
 function find(version){for(var i=0;i<HASSAN_RELEASES.length;i++)if(HASSAN_RELEASES[i].version===version)return HASSAN_RELEASES[i];return null;}
 function select(version){var release=find(version);if(busy||!release||!release.available)return;HASSAN_PAYLOAD=release;document.getElementById('selected-version').textContent='GoldHEN '+release.version;document.getElementById('selected-kind').textContent=(release.prerelease?'تجريبي':'إصدار سابق')+' · متوافق مع 9.00';for(var i=0;i<cards.length;i++){var selected=cards[i].getAttribute('data-version')===version;cards[i].className='release-card'+(selected?' selected':'');cards[i].setAttribute('aria-pressed',selected?'true':'false');}try{localStorage.setItem('hassan-goldhen-version',version);}catch(e){}}
 for(var c=0;c<cards.length;c++)cards[c].onclick=function(){select(this.getAttribute('data-version'));};
 try{select(localStorage.getItem('hassan-goldhen-version')||HASSAN_RELEASES[0].version);}catch(e){select(HASSAN_RELEASES[0].version);}
 if(!compatible)say('افتح هذه الصفحة على PS4 بنظام 9.00','التشغيل معطّل على هذا المتصفح. تقدر تقرأ الدليل من الحاسبة أو الهاتف.');
 else say('جاهز على PS4 9.00','اختار إصدارك واضغط تشغيل. أدخل الفلاشة فقط عند طلب المشغّل.');
 update();
 function fail(message){busy=true;update();say('توقّف التشغيل',message+' أغلق الصفحة وافتحها لمحاولة جديدة.');}
 function scripts(list,done){if(!list.length){done();return;}var script=document.createElement('script');script.src=list.shift();script.onload=function(){scripts(list,done);};script.onerror=function(){fail('تعذّر تحميل أحد ملفات المشغّل. أعد الاتصال واحفظ الكاش مرة أخرى.');};document.head.appendChild(script);}
 button.onclick=function(){
  if(button.disabled||busy||!compatible)return;
  busy=true;update();say('جارٍ تحميل GoldHEN وفحص بصمته','لا تدخل الفلاشة الآن. انتظر رسالة إدخال USB من المشغّل.');
  var xhr=new XMLHttpRequest();xhr.open('GET',HASSAN_PAYLOAD.url,true);xhr.responseType='arraybuffer';xhr.timeout=30000;
  xhr.onerror=xhr.ontimeout=function(){fail('تعذّر تحميل GoldHEN. افحص الاتصال أو أعد تجهيز الكاش.');};
  xhr.onload=function(){
   if(xhr.status!==200||!xhr.response||xhr.response.byteLength!==HASSAN_PAYLOAD.bytes){fail('ملف GoldHEN غير مكتمل أو غير متاح.');return;}
   var bytes=new Uint8Array(xhr.response);
   if(hassanSha256(bytes)!==HASSAN_PAYLOAD.sha256){fail('بصمة GoldHEN غير مطابقة للنسخة الرسمية المثبتة. لم يبدأ الاستغلال.');return;}
   window.hassanPayload=bytes;
   scripts(['vendor/int64.js','vendor/rop.js','vendor/kexploit.js','vendor/webkit.js','bridge.js'],function(){
    say('بدأت محاولة تشغيل 9.00','انتظر رسالة Insert USB now. لا تدخل الفلاشة قبل ظهورها.');
    window.setTimeout(function(){try{poc();}catch(e){fail('لم تكتمل المحاولة. افصل الفلاشة وأعد تشغيل الجهاز بالطريقة المعتادة.');}},1500);
   });
  };
  try{xhr.send();}catch(e){fail('المتصفح لم يتمكن من تحميل الملف المحلي.');}
 };
 window.hassanLoaderStatus=say;
})();
