/* Integration adapter. Upstream exploit files remain unchanged in vendor/. */
(function () {
 'use strict';
 var button=document.getElementById('start-loader'),status=document.getElementById('loader-status'),detail=document.getElementById('loader-detail');
 var firmware=document.getElementById('confirm-firmware'),usb=document.getElementById('confirm-usb');
 var compatible=/PlayStation 4[ \/]9\.00(?:[;\s\)]|$)/i.test(navigator.userAgent),busy=false;
 function say(a,b){status.textContent=a;detail.textContent=b;}
 function update(){button.disabled=busy||!compatible||!firmware.checked||!usb.checked;}
 firmware.onchange=usb.onchange=update;
 if(!compatible)say('افتح هذه الصفحة على PS4 بنظام 9.00','التشغيل معطّل على هذا المتصفح. تقدر تقرأ الدليل من الحاسبة أو الهاتف.');
 else say('متصفح PS4 9.00 — بانتظار تأكيدك','تأكد من رقم النظام وتجهيز الفلاشة، ثم علّم الخيارين واضغط تشغيل.');
 update();
 function fail(message){busy=true;update();say('توقّف التشغيل',message+' أغلق الصفحة وافتحها لمحاولة جديدة.');}
 function scripts(list,done){if(!list.length){done();return;}var script=document.createElement('script');script.src=list.shift();script.onload=function(){scripts(list,done);};script.onerror=function(){fail('تعذّر تحميل أحد ملفات المشغّل. أعد الاتصال واحفظ الكاش مرة أخرى.');};document.head.appendChild(script);}
 button.onclick=function(){
  if(button.disabled||busy||!compatible)return;
  busy=true;update();say('جارٍ تحميل GoldHEN وفحص بصمته','لا تدخل الفلاشة الآن. انتظر رسالة إدخال USB من المشغّل.');
  var xhr=new XMLHttpRequest();xhr.open('GET',HASSAN_PAYLOAD.url,true);xhr.responseType='arraybuffer';xhr.timeout=30000;
  xhr.onerror=xhr.ontimeout=function(){fail('تعذّر تحميل GoldHEN. افحص الاتصال أو أعد تجهيز الكاش.');};
  xhr.onload=function(){
   if(xhr.status!==200||!xhr.response||xhr.response.byteLength!==HASSAN_PAYLOAD.bytes){fail('ملف GoldHEN غير مكتمل أو غير متاح.');return;}
   var bytes=new Uint8Array(xhr.response);
   if(hassanSha256(bytes)!==HASSAN_PAYLOAD.sha256){fail('بصمة GoldHEN غير مطابقة للنسخة الرسمية المثبتة. لم يبدأ الاستغلال.');return;}
   window.hassanPayload=bytes;
   scripts(['vendor/int64.js','vendor/rop.js','vendor/kexploit.js','vendor/webkit.js','bridge.js'],function(){
    say('بدأت محاولة تشغيل 9.00','انتظر رسالة Insert USB now. لا تدخل الفلاشة قبل ظهورها.');
    window.setTimeout(function(){try{poc();}catch(e){fail('لم تكتمل المحاولة. افصل الفلاشة وأعد تشغيل الجهاز بالطريقة المعتادة.');}},1500);
   });
  };
  try{xhr.send();}catch(e){fail('المتصفح لم يتمكن من تحميل الملف المحلي.');}
 };
 window.hassanLoaderStatus=say;
})();
