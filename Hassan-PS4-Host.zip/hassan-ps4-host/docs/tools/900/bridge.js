/* pOOBs4 run_hax adapter: execute the pinned GoldHEN binary locally,
   replacing the upstream TCP payload receiver. Kernel/WebKit code is unchanged. */
function run_hax() {
 if(!window.hassanPayload||window.hassanPayload.length!==HASSAN_PAYLOAD.bytes)throw new Error('Payload was not preloaded');
 userland();
 if(chain.syscall(23,0).low!==0)kernel();
 var size=(window.hassanPayload.length+0x3fff)&~0x3fff;
 var buffer=chain.syscall(477,0,size,7,0x1000,0xffffffff,0);
 if(buffer.low===0xffffffff&&buffer.hi===0xffffffff)throw new Error('mmap failed');
 var writer=p.array_from_address(buffer,size/4);
 var bytes=window.hassanPayload;
 for(var i=0;i<bytes.length;i+=4)writer[i/4]=(bytes[i]|(bytes[i+1]<<8)|(bytes[i+2]<<16)|(bytes[i+3]<<24))>>>0;
 chain.fcall(window.syscalls[203],buffer,size);
 chain.fcall(buffer,0);
 chain.run();
 window.hassanLoaderStatus('انتهى استدعاء ملف GoldHEN','تأكد من ظهور إشعار GoldHEN وإعداداته على جهازك. رجوع استدعاء الملف وحده لا يؤكد التفعيل. افصل الفلاشة.');
}
