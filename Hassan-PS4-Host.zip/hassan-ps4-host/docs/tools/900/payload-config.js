// Pinned official release; generated during integration.
var HASSAN_PAYLOAD={url:'vendor/goldhen-2.4b18.bin',bytes:260160,sha256:'eb9fee5e9e3618c0a144a6fc6b8fc1ec7e89cf06483ad64ae7c1085efc9525a3'};
