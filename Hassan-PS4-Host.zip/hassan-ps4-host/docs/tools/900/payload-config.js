// Official release snapshot, 2026-10-31.
var HASSAN_RELEASES=[
  {
    "version": "2.4b18",
    "prerelease": true,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.4b18",
    "url": "vendor/releases/2.4b18/goldhen.bin",
    "bytes": 260160,
    "sha256": "eb9fee5e9e3618c0a144a6fc6b8fc1ec7e89cf06483ad64ae7c1085efc9525a3",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.4b18/GoldHEN_v2.4b18.7z",
    "archive_sha256": "d0c84c79f65df5afc79a00c578f33ab1aa70aeb9c205f1e789895dc7d4fca38d"
  },
  {
    "version": "2.4b17.3",
    "prerelease": true,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.4b17.3",
    "url": "vendor/releases/2.4b17.3/goldhen.bin",
    "bytes": 219456,
    "sha256": "790df4bb7e8873c08a860114275df773bc10b4a41c40ce5de7a69e366a4e1032",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.4b17.3/GoldHEN_v2.4b17.3.7z",
    "archive_sha256": "2c9838f3f6e3f412a7b2c731bf82f1f09d8439db1d4cee9acbbf043e3eeede8b"
  },
  {
    "version": "2.4b17.2",
    "prerelease": true,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.4b17.2",
    "url": "vendor/releases/2.4b17.2/goldhen.bin",
    "bytes": 296752,
    "sha256": "d434953e6979f3a037d2ccbfec32ecf35df1eb88c15f1497369fae8136f73088",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.4b17.2/GoldHEN_v2.4b17.2.7z",
    "archive_sha256": "d63dc646cb1fe5beb1be3a2e78b70a9531c75ed6a900415551291573189b0bc6"
  },
  {
    "version": "2.4b17",
    "prerelease": true,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.4b17",
    "url": "vendor/releases/2.4b17/goldhen.bin",
    "bytes": 296112,
    "sha256": "313a1ef8b52c5f2f5fccee32287c182220fe6737b903db0c01b42d31e8854bdb",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.4b17/GoldHEN_v2.4b17.7z",
    "archive_sha256": "d89ba3effb04717590dff7f6fc655927d7232706b360b4ca7cfaffb5395c05ab"
  },
  {
    "version": "2.3",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.3",
    "url": "vendor/releases/2.3/goldhen.bin",
    "bytes": 282648,
    "sha256": "c9b8f33d28258af9e80465da591868dada25a1454f30f63882668d5e0dcff9c2",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.3/GoldHEN_v2.3.7z",
    "archive_sha256": "fc49f6ada1d73da63187f27c4dc1e1569aff3c355d3d5ae5acf9a674e268ac68"
  },
  {
    "version": "2.2.4",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.2.4",
    "url": "vendor/releases/2.2.4/goldhen.bin",
    "bytes": 275192,
    "sha256": "8371a836b634a09887ebc0c5714e567e7a1ec750edc203f9510352b2466560b9",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.2.4/GoldHEN_v2.2.4.7z",
    "archive_sha256": "202a9da6fc40459ab2a95ea036d6b1b74456a99250620c989a19d381c165c802"
  },
  {
    "version": "2.2.3",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.2.3",
    "url": "vendor/releases/2.2.3/goldhen.bin",
    "bytes": 270424,
    "sha256": "cb135f5d8ae91b8d0a6e26f5e38642fae080e3067f08dd19ee4ce23b21c6c8e8",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.2.3/GoldHEN_v2.2.3.7z",
    "archive_sha256": "7c6269abe6f638803cb41275afd81e6b85dc7a4ee2d555f615f59d90a615c259"
  },
  {
    "version": "2.2.2",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.2.2",
    "url": "vendor/releases/2.2.2/goldhen.bin",
    "bytes": 251192,
    "sha256": "a791ddff6ccb5e8755682e3debdd62c191b9394efdd8c3b138575365c738e917",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.2.2/GoldHEN_v2.2.2.7z",
    "archive_sha256": "f978f17fcdd106c0bdc9fd8571ee0393624303e106c65a273a115389ce83632b"
  },
  {
    "version": "2.2.1",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.2.1",
    "url": "vendor/releases/2.2.1/goldhen.bin",
    "bytes": 253464,
    "sha256": "574d4351470c4ebdef9d40809c9ca3e03f0a70a5f057b330afc037436c797c56",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.2.1/GoldHEN_v2.2.1.7z",
    "archive_sha256": "e85edc4cc4c70f8b37eb81f7092ead2e20de7c5eee4cdc372d7205acfc644f75"
  },
  {
    "version": "2.2",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.2",
    "url": "vendor/releases/2.2/goldhen.bin",
    "bytes": 247160,
    "sha256": "e9bab80d735449a28a4b7a6bf94198bb4858e366542d495ba9f2eb63167342a8",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.2/GoldHEN_v2.2.7z",
    "archive_sha256": "2df12325b3a3deb1709880aff3b935f31970e672867580773b11deee36cfa147"
  },
  {
    "version": "2.1.2",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.1.2",
    "url": "vendor/releases/2.1.2/goldhen.bin",
    "bytes": 234872,
    "sha256": "c1b6b5cf2e2a54f0d5328d16f096f33616eabf1e1cdfbdb086a06b8092ed1fed",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.1.2/GoldHEN_v2.1.2.7z",
    "archive_sha256": "784b4e7c3b19a42d761ce5865433c90541b6d8f6ab4406346dfbda642cb4badf"
  },
  {
    "version": "2.1.1",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.1.1",
    "url": "vendor/releases/2.1.1/goldhen.bin",
    "bytes": 227992,
    "sha256": "61583ffb9dc2e2a2f4ba0bc6c2e2f0e6ec8c8d5c439abec518d3211737ede36a",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.1.1/GoldHEN_v2.1.1.7z",
    "archive_sha256": "87fddd04b8afc15332d077776c9354c72c4761ca8cdbc176cbc351a6af88973a"
  },
  {
    "version": "2.1",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.1",
    "url": "vendor/releases/2.1/goldhen.bin",
    "bytes": 233912,
    "sha256": "f2c1efc52e99b34dfe31c7b46943ed6f965403ae67fa194fdbf3fe5df828a852",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.1/GoldHEN_v2.1.7z",
    "archive_sha256": "5560df8da7f8de72e088dd1318a0f4e5423fff12054dd684eee95d695890f2ea"
  },
  {
    "version": "2.0b2",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.0b2",
    "url": "vendor/releases/2.0b2/goldhen.bin",
    "bytes": 229784,
    "sha256": "113d4e77e34a1a5b3cb4769b5aaffd1f557804b10aa06916add94e6da5b27ccd",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.0b2/GoldHEN_v2.0b2.7z",
    "archive_sha256": "49bb3a9d988d1a8e1e12db8e723f74cca4eb533033a500dff90c1b5bc5fb92b3"
  },
  {
    "version": "2.0b",
    "prerelease": false,
    "available": true,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/2.0b",
    "url": "vendor/releases/2.0b/goldhen.bin",
    "bytes": 229496,
    "sha256": "d878525bba7bba886119353c2c3e04b00c5331d8ca1de521030dd8af0648888e",
    "asset_url": "https://github.com/GoldHEN/GoldHEN/releases/download/2.0b/GoldHEN_v2.0b.7z",
    "archive_sha256": "95dd3fad40933f83b938ec19cda14b0632c7141899aa29fb605a1f4840d56dc8"
  },
  {
    "version": "1.1",
    "prerelease": false,
    "available": false,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/1.1"
  },
  {
    "version": "1.0",
    "prerelease": false,
    "available": false,
    "source": "https://github.com/GoldHEN/GoldHEN/releases/tag/1.0"
  }
];
var HASSAN_PAYLOAD=HASSAN_RELEASES[0];
