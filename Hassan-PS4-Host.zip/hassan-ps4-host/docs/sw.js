var CACHE='hassan-ps4-e6fdcbda1a71cf6a';
var FILES=["./", "assets/app.js", "assets/style.css", "index.html", "tools/900/index.html", "tools/900/sources.json"];
self.addEventListener('install',function(event){event.waitUntil(caches.open(CACHE).then(function(cache){return cache.addAll(FILES);}));});
self.addEventListener('activate',function(event){event.waitUntil(caches.keys().then(function(keys){return Promise.all(keys.filter(function(k){return k.indexOf('hassan-ps4-')===0&&k!==CACHE;}).map(function(k){return caches.delete(k);}));}).then(function(){return self.clients.claim();}));});
self.addEventListener('fetch',function(event){
 if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
 event.respondWith(caches.open(CACHE).then(function(cache){return cache.match(event.request,{ignoreSearch:true}).then(function(hit){return hit||fetch(event.request);});}));
});
