(function () {
'use strict';
var status = document.getElementById('cache-status'), detail = document.getElementById('cache-detail');
function say(a,b){status.textContent=a;detail.textContent=b;}
var ua=navigator.userAgent, match=ua.match(/PlayStation 4[ \/]([0-9.]+)/i);
document.getElementById('device').textContent=match ? 'PS4 '+match[1] : 'متصفح غير PS4';
function network(){document.getElementById('network').textContent=navigator.onLine?'متصل بالشبكة*':'غير متصل';}
network();window.addEventListener('online',network);window.addEventListener('offline',network);
var ac=window.applicationCache;
if(ac){
 ac.addEventListener('checking',function(){say('جارٍ فحص نسخة الواجهة','انتظر نتيجة الفحص قبل فصل الإنترنت.');});
 ac.addEventListener('downloading',function(){say('جارٍ حفظ الواجهة','لا تغلق المتصفح أثناء الحفظ.');});
 ac.addEventListener('progress',function(e){say('جارٍ حفظ الواجهة'+(e.total?' — '+Math.round(e.loaded/e.total*100)+'%':''),'يشمل الملفات المحلية فقط.');});
 ac.addEventListener('cached',function(){say('اكتمل حفظ الواجهة','أغلق المتصفح وافتح نفس العنوان دون نت للتحقق على جهازك. ملفات المشغّل مضمّنة؛ يلزم اختبار الجهاز.');});
 ac.addEventListener('noupdate',function(){say('نسخة الواجهة محفوظة','لم يتوفر تحديث. جرّب فتح نفس العنوان دون اتصال للتحقق.');});
 ac.addEventListener('updateready',function(){say('تحديث محفوظ وجاهز','أغلق الصفحة وافتحها لتطبيق نسخة الواجهة الجديدة.');});
 ac.addEventListener('error',function(){say('تعذّر فحص أو تحديث التخزين','قد توجد نسخة سابقة، لكن لم نتأكد من اكتمال النسخة الحالية. تحقق من الاتصال ثم أعد المحاولة.');});
 ac.addEventListener('obsolete',function(){say('النسخة المحفوظة غير صالحة','أعد فتح الموقع مع الإنترنت لإعادة الإعداد.');});
 if(ac.status===1){say('نسخة واجهة محلية موجودة','سيجري فحص التحديث عند توفر الاتصال. يلزم اختبار فتحها دون نت.');}
 document.getElementById('cache-button').onclick=function(){try{ac.update();}catch(e){say('انتظر اكتمال الحفظ الأول','إذا لم يبدأ الحفظ، أعد فتح الصفحة مع الإنترنت.');}};
}else if('serviceWorker' in navigator){
 say('التخزين متاح لهذا المتصفح','اضغط تجهيز التخزين لحفظ الواجهة. هذا لا يثبت توافق PS4.');
 document.getElementById('cache-button').onclick=function(){
 say('جارٍ حفظ الواجهة','انتظر اكتمال تجهيز التخزين.');
 navigator.serviceWorker.register('sw.js').then(function(){return navigator.serviceWorker.ready;}).then(function(){say('اكتمل حفظ الواجهة لهذا المتصفح','أعد فتح الموقع ثم اختبره دون اتصال. PS4 يحتاج اختبار AppCache مستقلاً.');}).catch(function(){say('تعذّر حفظ الواجهة','تحقق من اتصالك وأن الموقع يعمل عبر HTTPS، ثم أعد المحاولة.');});
 };
}else{say('التخزين غير مدعوم هنا','يمكن استخدام الواجهة مع الإنترنت. لم يُحفظ الموقع للأوفلاين.');document.getElementById('cache-button').disabled=true;}
var search=document.getElementById('game-search');search.addEventListener('input',function(){var q=search.value.toLowerCase().replace(/^\s+|\s+$/g,''),list=document.querySelectorAll('[data-game]'),count=0;for(var i=0;i<list.length;i++){var show=list[i].getAttribute('data-game').indexOf(q)!==-1;list[i].hidden=!show;if(show)count++;}document.getElementById('empty').hidden=count!==0;});
})();
(function(){'use strict';var field=document.getElementById('firmware'),help=document.getElementById('firmware-help');field.onchange=function(){help.textContent=field.value==='9.00'?'إصدارك يطابق المشغّل المدمج. افتح مشغّل GoldHEN من قسم الأدوات، واقرأ تعليمات تجهيز فلاشة exfathax. اختبار التفعيل الفعلي يتم على جهازك.':field.value==='other'?'تقدر تستخدم الواجهة والدليل. اعرف رقم النظام أولاً؛ أدوات 9.00 ليست مناسبة لكل الإصدارات.':'اختَر الإصدار حتى تظهر الخطوة المناسبة.';};})();
