from pathlib import Path
import hashlib, json
root = Path(__file__).resolve().parents[1] / 'docs'
files = sorted(p for p in root.rglob('*') if p.is_file() and p.name not in ('offline.appcache','sw.js','.nojekyll'))
paths = [p.relative_to(root).as_posix() for p in files]
version = hashlib.sha256(b''.join(p.relative_to(root).as_posix().encode()+p.read_bytes() for p in files)).hexdigest()[:16]
(root/'offline.appcache').write_text('CACHE MANIFEST\n# '+version+'\nCACHE:\n./\n'+'\n'.join(paths)+'\nNETWORK:\n*\n', encoding='utf-8')
sw = """var CACHE='hassan-ps4-__VERSION__';
var FILES=__FILES__;
self.addEventListener('install',function(event){event.waitUntil(caches.open(CACHE).then(function(cache){return cache.addAll(FILES);}));});
self.addEventListener('activate',function(event){event.waitUntil(caches.keys().then(function(keys){return Promise.all(keys.filter(function(k){return k.indexOf('hassan-ps4-')===0&&k!==CACHE;}).map(function(k){return caches.delete(k);}));}).then(function(){return self.clients.claim();}));});
self.addEventListener('fetch',function(event){
 if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
 event.respondWith(caches.open(CACHE).then(function(cache){return cache.match(event.request,{ignoreSearch:true}).then(function(hit){return hit||fetch(event.request);});}));
});
"""
(root/'sw.js').write_text(sw.replace('__VERSION__',version).replace('__FILES__',json.dumps(['./']+paths)),encoding='utf-8')
print('Cache version:',version,'files:',len(paths)+1)
