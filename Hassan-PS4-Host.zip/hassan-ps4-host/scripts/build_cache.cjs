const fs=require('fs'),path=require('path'),crypto=require('crypto');const root=path.resolve(__dirname,'../docs');
function walk(d){return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);}
const files=walk(root).filter(p=>!['offline.appcache','sw.js','.nojekyll'].includes(path.basename(p))).sort();const paths=files.map(p=>path.relative(root,p).replace(/\\/g,'/'));const hash=crypto.createHash('sha256');files.forEach((p,i)=>{hash.update(paths[i]);hash.update(fs.readFileSync(p));});const version=hash.digest('hex').slice(0,16);
fs.writeFileSync(path.join(root,'offline.appcache'),'CACHE MANIFEST\n# '+version+'\nCACHE:\n./\n'+paths.join('\n')+'\nNETWORK:\n*\n');
fs.writeFileSync(path.join(root,'sw.js'),`var CACHE='hassan-ps4-${version}';
var FILES=${JSON.stringify(['./'].concat(paths))};
self.addEventListener('install',function(e){e.waitUntil(caches.open(CACHE).then(function(c){return c.addAll(FILES);}));});
self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(keys){return Promise.all(keys.filter(function(k){return k.indexOf('hassan-ps4-')===0&&k!==CACHE;}).map(function(k){return caches.delete(k);}));}).then(function(){return self.clients.claim();}));});
self.addEventListener('fetch',function(e){if(e.request.method!=='GET'||new URL(e.request.url).origin!==self.location.origin)return;e.respondWith(caches.open(CACHE).then(function(c){return c.match(e.request,{ignoreSearch:true}).then(function(hit){return hit||fetch(e.request);});}));});
`);console.log('Cache refreshed',version,paths.length+1,'entries');
