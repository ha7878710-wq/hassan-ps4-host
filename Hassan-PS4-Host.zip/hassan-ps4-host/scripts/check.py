from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
import json
root=Path(__file__).resolve().parents[1]/'docs'
class Links(HTMLParser):
 def handle_starttag(self,tag,attrs):
  for key,val in attrs:
   if key in ('src','href','manifest') and val and not val.startswith('#') and not urlsplit(val).scheme:
    assert (self.base/unquote(val.split('#')[0])).resolve().exists(), (self.base,val)
for page in root.rglob('*.html'):
 parser=Links();parser.base=page.parent;parser.feed(page.read_text())
lines=(root/'offline.appcache').read_text().splitlines(); active=False
for line in lines:
 if line=='CACHE:': active=True;continue
 if line=='NETWORK:':break
 if active and line and not line.startswith('#'): assert (root/line).exists(),line
assert json.loads((root/'tools/900/sources.json').read_text())['enabled'] is False
assert '<html lang="ar" dir="rtl"' in (root/'index.html').read_text()
print('PASS: local links, cache entries, RTL, disabled unconfigured tools')
